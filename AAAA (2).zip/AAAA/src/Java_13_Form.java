import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;

public class Java_13_Form extends Frame { //繼承
    public Java_13_Form(){
        this.setLocation(100,50); //位置
        this.setTitle("First Form"); //標題
        this.setSize(500,500); //標單寬度,長度
        this.setVisible(true); //顯示表單
        this.setLayout(null); //自行定義版面設置
    }
    public static void main(String[] args) {
         Frame frm = new Java_13_Form();
         Font font = new Font(Font.DIALOG_INPUT, Font.PLAIN, 35); //設定字型大小和字型
         Label lab = new Label();
         frm.setBackground(Color.BLACK);
         lab.setLocation(50,225);
         lab.setSize(400,50);
         lab.setBackground(Color.yellow);
         lab.setFont(font);
         lab.setText("Hello I'm lucas !");
         frm.add(lab); //將lab加入frm
    }
}